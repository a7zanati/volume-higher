(async () => {
  vhI18n();
  const $ = (id) => document.getElementById(id);
  const t = (k) => chrome.i18n.getMessage(k);
  let st = await vhLoad();

  function renderSites() {
    const ul = $('sites');
    ul.innerHTML = '';
    const keys = Object.keys(st.sites);
    if (!keys.length) { const li = document.createElement('li'); li.textContent = t('optNoSites'); ul.appendChild(li); return; }
    keys.forEach((h) => {
      const li = document.createElement('li');
      const d = document.createElement('span');
      d.className = 'd';
      d.textContent = h + ' — ' + (st.sites[h].auto ? 'Auto' : Math.round(st.sites[h].boost * 100) + '%');
      const b = document.createElement('button');
      b.textContent = t('optDelete');
      b.onclick = async () => { delete st.sites[h]; await vhSave(st); renderSites(); };
      li.append(d, b);
      ul.appendChild(li);
    });
  }
  function fill() {
    $('autoMaxBoost').value = st.global.autoMaxBoost;
    $('autoTargetDb').value = st.global.autoTargetDb;
    $('warnAbove').value = st.global.warnAbove;
    $('limiterEnabled').checked = st.global.limiterEnabled;
    $('excluded').value = st.excluded.join('\n');
    renderSites();
  }
  const flash = (m) => { $('msg').textContent = m; setTimeout(() => ($('msg').textContent = ''), 2500); };
  const num = (id, a, b, d) => { const v = parseFloat($(id).value); return isNaN(v) ? d : Math.min(Math.max(v, a), b); };

  $('save').onclick = async () => {
    st = await vhLoad();
    st.global = {
      autoMaxBoost: num('autoMaxBoost', 1, 6, 4),
      autoTargetDb: num('autoTargetDb', -40, -6, -20),
      warnAbove: num('warnAbove', 1, 6, 3),
      limiterEnabled: $('limiterEnabled').checked
    };
    st.excluded = $('excluded').value.split('\n').map((s) => s.trim().toLowerCase()).filter(Boolean);
    await vhSave(st);
    flash(t('optSaved'));
  };
  $('export').onclick = () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(st, null, 2)], { type: 'application/json' }));
    a.download = 'volume-higher-settings.json';
    a.click();
  };
  $('import').onclick = () => $('file').click();
  $('file').onchange = async (e) => {
    try {
      const data = JSON.parse(await e.target.files[0].text());
      if (typeof data !== 'object' || !data.global) throw new Error('bad');
      await vhSave(data);
      st = await vhLoad();
      fill();
      flash(t('optSaved'));
    } catch (err) { flash(t('optImportBad')); }
  };
  fill();
})();

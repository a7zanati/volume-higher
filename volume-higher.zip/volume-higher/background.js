// Volume Higher - Service Worker
// المطور: أحمد الزناتي | http://www.youtube.com/@a7zanati
const HARD_MAX = 6;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_HOST') {
    let host = '';
    try { host = new URL(sender.tab.url).hostname; } catch (e) {}
    sendResponse({ host });
  } else if (msg.type === 'REPORT' && sender.tab) {
    const id = sender.tab.id;
    const text = msg.auto ? 'A' : (Math.abs(msg.boost - 1) > 0.001 ? String(Math.round(msg.boost * 100)) : '');
    chrome.action.setBadgeText({ tabId: id, text });
    chrome.action.setBadgeBackgroundColor({ tabId: id, color: '#d9480f' });
    chrome.storage.session.set({ ['t' + id]: { boost: msg.boost, auto: msg.auto } });
  }
});

chrome.commands.onCommand.addListener(async (cmd) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:/.test(tab.url || '')) return;
  const host = new URL(tab.url).hostname;
  const k = 't' + tab.id;
  const cur = (await chrome.storage.session.get(k))[k];
  const store = (await chrome.storage.local.get('vh')).vh || {};
  const site = store.sites && store.sites[host];
  let b = cur ? cur.boost : (site ? site.boost : 1);
  if (cmd === 'volume-up') b += 0.1;
  else if (cmd === 'volume-down') b -= 0.1;
  else b = 1;
  b = Math.round(Math.min(Math.max(b, 0), HARD_MAX) * 100) / 100;
  chrome.tabs.sendMessage(tab.id, { type: 'SET', boost: b, auto: false }).catch(() => {});
  if (site) {
    store.sites[host] = { boost: b, auto: false };
    chrome.storage.local.set({ vh: store });
  }
});

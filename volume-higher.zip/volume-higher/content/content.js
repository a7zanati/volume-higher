// Volume Higher - Content Script
// MediaElementSource -> (Analyser tap) + Gain -> Limiter -> destination
(() => {
  if (window.__vhLoaded) return;
  window.__vhLoaded = true;

  const HARD_MAX = 6;
  let S = { global: { autoMaxBoost: 4, limiterEnabled: true, autoTargetDb: -20, warnAbove: 3 }, sites: {}, excluded: [] };
  let host = location.hostname, boost = 1, auto = false, excluded = false;
  let unsupported = 0, reportedNonDefault = false, gestureWait = false;
  const chains = new Map();
  const buf = new Float32Array(2048);

  const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
  const send = (m) => { try { chrome.runtime.sendMessage(m).catch(() => {}); } catch (e) {} };
  const active = () => !excluded && (boost !== 1 || auto);

  function supported(m) {
    if (m.srcObject) return true;
    let u;
    try { u = new URL(m.currentSrc || m.src, location.href); } catch (e) { return true; }
    if (u.protocol === 'blob:' || u.protocol === 'data:' || u.origin === location.origin) return true;
    return m.crossOrigin !== null;
  }

  function wire(c) {
    try { c.gain.disconnect(); } catch (e) {}
    if (S.global.limiterEnabled) c.gain.connect(c.lim);
    else c.gain.connect(c.ctx.destination);
  }

  function waitGesture() {
    if (gestureWait) return;
    gestureWait = true;
    const go = () => { gestureWait = false; refresh(); };
    ['pointerdown', 'keydown'].forEach((ev) => window.addEventListener(ev, go, { once: true, capture: true }));
  }

  function attach(m) {
    if (chains.has(m) || m.__vhFail) return;
    if (!m.currentSrc && !m.srcObject) return;
    if (navigator.userActivation && !navigator.userActivation.hasBeenActive) { waitGesture(); return; }
    if (!supported(m)) { m.__vhFail = true; unsupported++; return; }
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const src = ctx.createMediaElementSource(m);
      const tap = ctx.createAnalyser();
      tap.fftSize = 2048;
      const gain = ctx.createGain();
      const lim = ctx.createDynamicsCompressor();
      lim.threshold.value = -3; lim.knee.value = 0; lim.ratio.value = 20;
      lim.attack.value = 0.003; lim.release.value = 0.1;
      lim.connect(ctx.destination);
      src.connect(tap);
      src.connect(gain);
      const c = { ctx, tap, gain, lim, env: -120 };
      wire(c);
      chains.set(m, c);
      ctx.resume().catch(() => {});
      m.addEventListener('play', () => ctx.resume().catch(() => {}));
    } catch (e) {
      m.__vhFail = true; unsupported++;
    }
  }

  function setGain(c, v, tc) { c.gain.gain.setTargetAtTime(v, c.ctx.currentTime, tc); }

  function applyAll() {
    chains.forEach((c) => {
      if (excluded) setGain(c, 1, 0.05);
      else if (!auto) setGain(c, clamp(boost, 0, HARD_MAX), 0.05);
    });
  }

  function report() {
    const nonDefault = boost !== 1 || auto;
    if (!nonDefault && !reportedNonDefault) return;
    reportedNonDefault = nonDefault;
    send({ type: 'REPORT', boost, auto });
  }

  function refresh() {
    if (active()) document.querySelectorAll('video,audio').forEach(attach);
    applyAll();
    report();
  }

  setInterval(() => {
    chains.forEach((c, m) => {
      if (m.paused || c.ctx.state !== 'running') return;
      c.tap.getFloatTimeDomainData(buf);
      let sum = 0;
      for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
      const rms = Math.sqrt(sum / buf.length);
      const db = rms > 0 ? 20 * Math.log10(rms) : -120;
      c.env = Math.max(db, c.env - 1.5);
      if (!auto || excluded || m.muted || c.env < -60) return;
      const maxB = clamp(S.global.autoMaxBoost, 1, HARD_MAX);
      const need = clamp(Math.pow(10, (S.global.autoTargetDb - c.env) / 20), 1, maxB);
      const cur = c.gain.gain.value;
      setGain(c, need, need > cur ? 1.5 : 0.2);
    });
  }, 250);

  function loadSettings(v) {
    const g = v || {};
    S = {
      global: Object.assign({}, S.global, g.global || {}),
      sites: g.sites || {},
      excluded: g.excluded || []
    };
    excluded = S.excluded.includes(host);
    const s = S.sites[host];
    if (s) { boost = s.boost; auto = !!s.auto; }
    chains.forEach(wire);
    refresh();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SET') {
      if (typeof msg.boost === 'number') boost = clamp(msg.boost, 0, HARD_MAX);
      if (typeof msg.auto === 'boolean') auto = msg.auto;
      refresh();
    } else if (msg.type === 'PROBE') {
      let level = -120;
      chains.forEach((c) => { if (c.env > level) level = c.env; });
      send({ type: 'STATE', count: chains.size, unsupported, level, boost, auto });
    }
  });

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && ch.vh) loadSettings(ch.vh.newValue);
  });

  new MutationObserver((muts) => {
    if (!active()) return;
    for (const mu of muts) {
      for (const n of mu.addedNodes) {
        if (n.nodeType !== 1) continue;
        if (n.matches && n.matches('video,audio')) attach(n);
        if (n.querySelectorAll) n.querySelectorAll('video,audio').forEach(attach);
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true });

  const onMedia = (e) => { if (active() && e.target instanceof HTMLMediaElement) attach(e.target); };
  document.addEventListener('play', onMedia, true);
  document.addEventListener('loadedmetadata', onMedia, true);

  const start = () => chrome.storage.local.get('vh').then((r) => loadSettings(r.vh)).catch(() => {});
  try {
    chrome.runtime.sendMessage({ type: 'GET_HOST' })
      .then((r) => { if (r && r.host) host = r.host; })
      .catch(() => {})
      .finally(start);
  } catch (e) { start(); }
})();

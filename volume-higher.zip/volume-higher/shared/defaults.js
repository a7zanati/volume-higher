const VH_DEFAULTS = {
  schemaVersion: 1,
  global: { autoMaxBoost: 4, limiterEnabled: true, autoTargetDb: -20, warnAbove: 3 },
  sites: {},
  excluded: []
};
async function vhLoad() {
  const r = await chrome.storage.local.get('vh');
  const v = r.vh || {};
  return {
    schemaVersion: 1,
    global: Object.assign({}, VH_DEFAULTS.global, v.global || {}),
    sites: v.sites || {},
    excluded: v.excluded || []
  };
}
function vhSave(s) { return chrome.storage.local.set({ vh: s }); }
function vhI18n() {
  document.documentElement.dir = chrome.i18n.getMessage('@@bidi_dir');
  document.documentElement.lang = chrome.i18n.getMessage('@@ui_locale').replace('_', '-');
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    el.textContent = chrome.i18n.getMessage(el.dataset.i18n);
  });
}

(async () => {
  vhI18n();
  const $ = (id) => document.getElementById(id);
  const t = (k) => chrome.i18n.getMessage(k);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let host = '';
  try { const u = new URL(tab.url); if (/^https?:$/.test(u.protocol)) host = u.hostname; } catch (e) {}
  $('opts').onclick = (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); };
  if (!host) { $('main').hidden = true; $('unsupported').hidden = false; return; }
  $('host').textContent = host;

  let st = await vhLoad();
  const site = st.sites[host];
  let boost = site ? site.boost : 1;
  let auto = site ? !!site.auto : false;
  let touched = false;
  $('remember').checked = !!site;
  $('exclude').checked = st.excluded.includes(host);

  [100, 150, 200, 300, 400].forEach((p) => {
    const b = document.createElement('button');
    b.textContent = p + '%';
    b.onclick = () => setBoost(p / 100);
    $('presets').appendChild(b);
  });
  const rb = document.createElement('button');
  rb.textContent = t('reset');
  rb.className = 'reset';
  rb.onclick = () => setBoost(1);
  $('presets').appendChild(rb);

  function render() {
    const hot = boost > st.global.warnAbove;
    $('slider').value = Math.round(boost * 100);
    $('pct').textContent = Math.round(boost * 100) + '%';
    $('pct').classList.toggle('hot', hot);
    $('warn').hidden = !hot;
    $('auto').checked = auto;
  }
  async function persist() {
    st = await vhLoad();
    if ($('remember').checked) { st.sites[host] = { boost, auto }; await vhSave(st); }
  }
  function push() {
    touched = true;
    chrome.tabs.sendMessage(tab.id, { type: 'SET', boost, auto }).catch(() => {});
    render();
    persist();
  }
  function setBoost(v) { boost = v; auto = false; push(); }

  $('slider').oninput = (e) => setBoost(e.target.value / 100);
  $('auto').onchange = (e) => { auto = e.target.checked; push(); };
  $('remember').onchange = async (e) => {
    st = await vhLoad();
    if (e.target.checked) st.sites[host] = { boost, auto }; else delete st.sites[host];
    await vhSave(st);
  };
  $('exclude').onchange = async (e) => {
    st = await vhLoad();
    st.excluded = st.excluded.filter((h) => h !== host);
    if (e.target.checked) st.excluded.push(host);
    await vhSave(st);
  };

  const frames = {};
  chrome.runtime.onMessage.addListener((m, s) => {
    if (m.type !== 'STATE' || !s.tab || s.tab.id !== tab.id) return;
    frames[s.frameId] = m;
    if (!touched && !site && (m.boost !== 1 || m.auto)) { boost = m.boost; auto = m.auto; render(); }
    let count = 0, unsupp = 0, level = -120;
    Object.values(frames).forEach((f) => { count += f.count; unsupp += f.unsupported; level = Math.max(level, f.level); });
    $('meterBar').style.width = Math.max(0, Math.min(100, ((level + 60) / 60) * 100)) + '%';
    $('status').textContent = unsupp && !count ? t('statusUnsupported')
      : count ? t('statusMedia') + ' ' + count
      : t('statusNone');
  });
  const probe = () => chrome.tabs.sendMessage(tab.id, { type: 'PROBE' }).catch(() => {});
  render();
  $('status').textContent = t('statusNone');
  probe();
  setInterval(probe, 300);
})();
